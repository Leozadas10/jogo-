function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let playerCar;
let obstacles = [];
let score = 0;

function setup() {
  createCanvas(400, 600);
  playerCar = new Car(width / 2, height - 100);
}

function draw() {
  background(50);
  
  // Exibir e atualizar o carro do jogador
  playerCar.display();
  playerCar.move();
  
  // Criar novos obstáculos
  if (frameCount % 60 === 0) {
    obstacles.push(new Obstacle(random(50, width - 50), -20));
  }
  
  // Exibir e mover obstáculos
  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].display();
    obstacles[i].move();
    
    // Verificar colisão
    if (obstacles[i].hits(playerCar)) {
      noLoop();
      textSize(32);
      fill(255, 0, 0);
      textAlign(CENTER);
      text("Game Over!", width / 2, height / 2);
    }
    
    // Remover obstáculos que saíram da tela
    if (obstacles[i].offScreen()) {
      obstacles.splice(i, 1);
      score++;
    }
  }
  
  // Exibir pontuação
  textSize(16);
  fill(255);
  textAlign(LEFT);
  text("Pontuação: " + score, 10, 20);
}

class Car {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.width = 40;
    this.height = 70;
  }
  
  display() {
    fill(0, 0, 255);
    rect(this.x, this.y, this.width, this.height, 10);
  }
  
  move() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= 5;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += 5;
    }
    this.x = constrain(this.x, 0, width - this.width);
  }
}

class Obstacle {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.width = 40;
    this.height = 40;
    this.speed = 5;
  }
  
  display() {
    fill(255, 0, 0);
    rect(this.x, this.y, this.width, this.height);
  }
  
  move() {
    this.y += this.speed;
  }
  
  offScreen() {
    return this.y > height;
  }
  
  hits(car) {
    return (
      this.x < car.x + car.width &&
      this.x + this.width > car.x &&
      this.y < car.y + car.height &&
      this.y + this.height > car.y
    );
  }
}
